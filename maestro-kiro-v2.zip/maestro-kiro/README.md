<div align="center">

# Maestro Kiro

**Bạn hỏi. Kiro làm — và tự ghi lại việc đã làm.**

Một workspace [Kiro](https://kiro.dev) gọn, để ship tính năng **full-stack** thật nhanh —
**Java/Spring Boot · Node.js · Next.js · ReactJS** — không phiếu task, không pipeline phê duyệt. Chỉ
*Hiểu → Làm → Ghi*.

[![License: MIT](https://img.shields.io/badge/License-MIT-black.svg)](LICENSE)
[![Made for Kiro](https://img.shields.io/badge/made%20for-Kiro-5A31F4.svg)](https://kiro.dev)
[![Stack](https://img.shields.io/badge/stack-Spring%20Boot%20%C2%B7%20Node%20%C2%B7%20Next%20%C2%B7%20React-success.svg)](.kiro/steering/tech.md)
[![Skills](https://img.shields.io/badge/skills-57-blue.svg)](.kiro/skills/CATALOG.md)
[![CI](https://img.shields.io/badge/CI-validate-brightgreen.svg)](.github/workflows/validate.yml)

</div>

---

## Vì sao

Đa số setup agent bắt bạn trông chừng một quy trình: viết ticket, phân tích, duyệt kế hoạch, bàn giao
cho coder, chạy QC. Nhiều nghi thức, chậm việc thật.

**Kiro làm ngược lại.** Bạn nói bằng ngôn ngữ tự nhiên → Kiro đọc code liên quan, khớp convention của
bạn, thực hiện thay đổi, và thêm một mục trung thực vào `WORKLOG.md`. Nó chỉ dừng để hỏi trước những
việc không thể hoàn tác (xoá, deploy, push, secret). Vậy thôi.

Nó được tinh chỉnh cho một mảng full-stack tập trung nên thật sự giỏi: **backend Spring Boot hoặc
Node.js, frontend React hoặc Next.js, và các thư viện UI/ORM/auth bạn đang dùng** — 57 skill đã tuyển,
không bloat.

**Nó theo dự án của bạn, không áp khuôn.** Kiro đọc cách codebase của bạn thật sự được viết — layering,
đặt tên, thư viện, luồng — và khớp theo đó. Steering và skills là kiến thức khởi đầu; convention thật
của dự án luôn thắng.

## Bắt đầu nhanh

**Khuyến nghị — cài global một lần, rồi init cho từng dự án** (không phải cầm `.kiro/` đi theo):

```bash
# 1. Cài phần dùng-chung vào ~/.kiro (contract, skills, hooks, template). Chạy một lần.
./install.sh

# 2. Trong dự án bất kỳ, tạo phần riêng của dự án:
cd ~/work/my-app && /path/to/maestro-kiro/kiro-init.sh
#   -> tạo ./.kiro/steering/{product,tech,structure,inventory}.md  +  ./WORKLOG.md
#      (WORKLOG.md được loại khỏi git cục bộ, không commit, không đụng .gitignore của dự án)

# 3. Mở dự án trong Kiro và cứ nói:
#    "thêm endpoint GET /users/{id} trả về UserDto"
#    "phân tích luồng nghiệp vụ của API tạo đơn hàng"
```

**Hoặc — tự chứa theo từng dự án** (không cài global): copy nguyên thư mục vào.

```bash
cp -R maestro-kiro/.kiro your-project/ && cp maestro-kiro/WORKLOG.md your-project/
```

### Global vs per-project

Kiro đọc cả `~/.kiro/` (global, mọi dự án) lẫn `./.kiro/` (dự án này); khi trùng, dự án ghi đè global.

| Global `~/.kiro/` (cài một lần) | Per-project `./.kiro/` + gốc dự án |
|---|---|
| `steering/kiro.md`, `steering/git.md` (contract) | `steering/product.md`, `tech.md`, `structure.md`, `inventory.md` (dữ kiện thật của dự án) |
| `skills/` (57), `hooks/`, template spec/analysis, `settings/mcp.json` | output `specs/`, `analysis/` · **`WORKLOG.md` ở gốc dự án** |

> **WORKLOG.md là per-project** (ở gốc dự án) — ghi việc Kiro làm trong *dự án đó*, nên không để global.
> `kiro-init.sh` tự loại nó khỏi git qua **`.git/info/exclude`** (cục bộ, không commit, **không đụng
> `.gitignore` của dự án**). Tương tự, steering `product/tech/structure/inventory` cũng per-project.
> Lưu ý: Kiro chưa inject steering global dùng `inclusion: fileMatch`, nên `inventory.md` để per-project
> (vốn cũng đúng).

Lần đầu, kể cho Kiro về dự án: điền `.kiro/steering/product.md` và để nó quét điền nốt `tech.md` /
`structure.md` / `inventory.md` (hoặc bật hook `first-run-steering` để tự động). Sau đó Kiro biết stack,
convention, và các thành phần dùng chung, khỏi quét lại.

## Nó hoạt động thế nào

```text
Bạn hỏi
   │
   ▼
Hiểu    nhận diện stack/tầng (Spring · Node · React · Next · DB/UI),
        khớp convention trong .kiro/steering/structure.md, nạp skill phù hợp
Làm     thực hiện trực tiếp — không ticket, không cổng, không bàn giao; tái dùng cái có sẵn
Kiểm    build/typecheck/test vùng đã đổi; không dead code, một code path
Ghi     thêm một mục vào WORKLOG.md (yêu cầu · đã làm · files · ghi chú)
Báo     tóm tắt ngắn + assumption
```

Với **feature lớn/mơ hồ**, Kiro chuyển sang **spec mode** (`requirements → design → tasks`, xem dưới).
Thay đổi nhỏ, rõ thì đi thẳng luồng trên.

Kiro chỉ xác nhận trước với các thao tác không-hoàn-tác/ra-ngoài: xoá dữ liệu, deploy, `git push`, ghi
secret, hoặc quyết định hai-hướng thật sự.

**Git luôn do bạn điều khiển.** Kiro không bao giờ tự commit/branch/push — mọi thao tác git đợi tín
hiệu của bạn, *mỗi lần* ("commit" lần trước không cho phép lần sau). Git-flow khi bạn yêu cầu nằm ở
[`.kiro/steering/git.md`](.kiro/steering/git.md).

## Có gì bên trong

```text
.kiro/
├── steering/        kiến thức dự án Kiro nạp mỗi phiên
│   ├── kiro.md          contract vận hành (Hiểu → Làm → Ghi)
│   ├── product.md       bạn đang xây gì
│   ├── tech.md          stack: Spring Boot · Node.js · Next.js · React + thư viện UI/ORM/auth
│   ├── structure.md     convention của bạn (layering BE, hook/component chung/style FE)
│   ├── inventory.md     sổ component / hook / helper dùng chung — để Kiro TÁI DÙNG
│   └── git.md           git-flow + luật: git chỉ khi bạn ra tín hiệu
├── skills/          57 Kiro workspace Agent Skills (tự kích hoạt theo task) + CATALOG.md
├── specs/           spec mode TUỲ CHỌN cho feature lớn (requirements → design → tasks)
├── analysis/        tài liệu phân tích luồng/nghiệp vụ (tiếng Việt, chỉ đọc) để bạn xác nhận
├── hooks/           automation *.kiro.hook TUỲ CHỌN (mặc định tắt — bật cái bạn muốn)
└── settings/mcp.json   MCP servers (mặc định rỗng)
WORKLOG.md           bản ghi việc Kiro làm (ở gốc dự án, không commit)
```

**Trí nhớ tái dùng:** Kiro giữ `inventory.md` — sổ component, hook, helper dùng chung của bạn — và tra
trước khi viết cái mới, để tái dùng thay vì tạo trùng.

**Hiểu trước khi sửa:** nói *"phân tích luồng / nghiệp vụ của API X"* và Kiro dò code end-to-end rồi
viết một tài liệu **tiếng Việt** (kèm trích `file:line`) vào `.kiro/analysis/` để bạn đọc và xác nhận —
không sửa code cho tới khi bạn chốt. Tài liệu cho user viết tiếng Việt; code và thuật ngữ giữ tiếng Anh.

## Spec mode (tuỳ chọn)

Với feature lớn hoặc mơ hồ, bảo Kiro "làm spec" và nó chuyển sang quy trình spec của Kiro —
`requirements.md → design.md → tasks.md` trong `.kiro/specs/<feature>/`, duyệt theo thứ tự, rồi làm
từng task. Việc thường ngày bỏ qua bước này và đi thẳng Hiểu → Làm → Ghi. Xem
[`.kiro/specs/README.md`](.kiro/specs/README.md).

## Skills

57 skill trải khắp **Backend — Java/Spring Boot** (`java-spring-development`, `spring-boot-engineer`, …),
**Backend — Node.js** (`nodejs-backend-patterns`, `nestjs-clean-typescript`, `fastify-typescript`,
`graphql`, …), **Frontend — React** (`react`, `react-query`, `redux-toolkit`, `zustand`, …),
**Frontend — Next.js** (`next-best-practices`, `next-cache-components`, `native-data-fetching`,
`deploy-to-vercel`, …), **thư viện UI** (shadcn, MUI, Tailwind, styled-components, framer-motion, …),
**Data & ORM** (Postgres, MySQL, Redis, Supabase, Neon, Prisma, Drizzle, TypeORM), **Auth**
(`better-auth-best-practices`), và **xuyên suốt** (debug, test, đọc-hiểu code). Xem
[`.kiro/skills/CATALOG.md`](.kiro/skills/CATALOG.md).

Đây là **Kiro workspace Agent Skills** (`.kiro/skills/<tên>/SKILL.md`, định dạng agentskills.io) — Kiro
tự kích hoạt một skill khi description khớp task, bạn không cần wire tay.
([tài liệu skills của Kiro](https://kiro.dev/docs/skills/))

## Dùng với Claude Code (tuỳ chọn)

Repo này làm cho **Kiro IDE**, nơi tự đọc `.kiro/steering/`. Để dùng cùng contract trong **Claude
Code**, thêm một file `CLAUDE.md` một dòng:

```text
@.kiro/steering/kiro.md
```

## License

[MIT](LICENSE).
