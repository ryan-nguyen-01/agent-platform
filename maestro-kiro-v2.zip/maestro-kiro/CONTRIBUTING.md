# Đóng góp

Cảm ơn bạn cải thiện Maestro Kiro. Đây là workspace nhỏ, docs-first, nên đóng góp chủ yếu vào nội dung
`.kiro/`.

## Cái gì nằm ở đâu

- `.kiro/steering/` — contract vận hành + template kiến thức dự án. Giữ thay đổi gọn và khớp cách Kiro
  thật sự đọc steering ([docs](https://kiro.dev/docs/steering/)).
- `.kiro/skills/` — Kiro workspace Agent Skills (`<tên>/SKILL.md`, frontmatter agentskills.io:
  `name` + `description` giàu từ khoá). Giữ bộ skill tập trung vào mảng Java/Spring · Node · Next ·
  React; cập nhật `CATALOG.md` khi thêm/bớt.
- `.kiro/hooks/` — JSON `*.kiro.hook`, hợp lệ theo [định dạng hooks](https://kiro.dev/docs/hooks/). Hook
  mới nên **mặc định tắt**.
- `.kiro/specs/`, `.kiro/analysis/` — template quy trình; spec `example-*` chỉ để minh hoạ.

## Quy ước

- Tài liệu cho user (analysis, inventory, worklog, requirements/design của spec) viết **tiếng Việt**;
  code và thuật ngữ kỹ thuật giữ tiếng Anh.
- Giữ gọn — giá trị của repo là nhỏ và dễ nhận diện. Đừng thêm lại bloat framework.
- Validate trước khi mở PR: `*.kiro.hook` và `settings/mcp.json` là JSON hợp lệ; front-matter steering
  (`inclusion:`) nằm ở dòng đầu.

## PR

Commit nhỏ, tập trung, message rõ. Mô tả đổi gì và vì sao.
