#!/usr/bin/env bash
# Cài phần dùng-chung (không phụ thuộc dự án) của Maestro Kiro vào ~/.kiro/ (global).
# Chạy một lần. Mỗi dự án sau đó chạy kiro-init.sh (hoặc bật hook first-run-steering).
set -euo pipefail

SRC="$(cd "$(dirname "$0")" && pwd)/.kiro"
DEST="$HOME/.kiro"

echo "Cài global Maestro Kiro:  $SRC  ->  $DEST"
mkdir -p "$DEST/steering" "$DEST/skills" "$DEST/hooks" "$DEST/specs" "$DEST/analysis" \
         "$DEST/settings" "$DEST/.templates/steering"

# 1) Contract vận hành + luật git — giống nhau ở mọi dự án (steering global).
cp "$SRC/steering/kiro.md" "$SRC/steering/git.md" "$DEST/steering/"
echo "  steering: kiro.md, git.md"

# 2) Skills, hooks — dùng lại ở mọi nơi.
cp -R "$SRC/skills/." "$DEST/skills/"
cp -R "$SRC/hooks/."  "$DEST/hooks/"
echo "  đã copy skills/ + hooks/"

# 3) Hướng dẫn + template cho spec & analysis (tham chiếu).
cp "$SRC/specs/README.md" "$DEST/specs/";      cp -R "$SRC/specs/_template" "$DEST/specs/"
cp "$SRC/analysis/README.md" "$DEST/analysis/"; cp -R "$SRC/analysis/_template" "$DEST/analysis/"
echo "  đã copy template specs/ + analysis/"

# 4) MCP: giữ cấu hình global đã có, không ghi đè.
if [ -f "$DEST/settings/mcp.json" ]; then echo "  settings/mcp.json đã có — giữ nguyên"; else
  cp "$SRC/settings/mcp.json" "$DEST/settings/mcp.json"; echo "  tạo settings/mcp.json"; fi

# 5) Template RIÊNG của dự án cho kiro-init (Kiro không nạp; chỉ dùng để scaffold dự án).
cp "$SRC/steering/product.md" "$SRC/steering/tech.md" "$SRC/steering/structure.md" \
   "$SRC/steering/inventory.md" "$DEST/.templates/steering/"
cp "$(dirname "$SRC")/WORKLOG.md" "$DEST/.templates/WORKLOG.md"
echo "  đã đặt template per-project vào ~/.kiro/.templates/"

echo
echo "Xong. Contract, skills, hooks giờ áp dụng cho MỌI dự án (Kiro đọc ~/.kiro)."
echo "Trong một dự án, chạy:  kiro-init.sh   (tạo ./.kiro/steering/* + ./WORKLOG.md)"
