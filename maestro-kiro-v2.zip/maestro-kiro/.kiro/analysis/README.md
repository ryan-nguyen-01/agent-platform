# Analysis — phân tích luồng & nghiệp vụ

Khi người dùng yêu cầu **"phân tích luồng / nghiệp vụ của API X"** (hoặc một use-case, một màn hình),
Kiro **dò code thật rất kỹ** rồi viết một file phân tích bằng **tiếng Việt** vào đây để người dùng đọc
và **xác nhận** — KHÔNG sửa code trong bước này.

```text
.kiro/analysis/<ten-api>.md     ví dụ: .kiro/analysis/order-create.md
```

## Quy trình

1. **Dò end-to-end** theo code thật (không đoán): entrypoint → controller → validation/DTO → service /
   business rules → repository / truy vấn DB → gọi service ngoài / event / message → response → xử lý
   lỗi & edge case → auth/phân quyền → side effect (gửi mail, ghi log, cập nhật cache…).
2. **Trích dẫn vị trí thật** (đường dẫn `file:line`) cho mỗi bước — để người dùng kiểm chứng.
3. **Viết file** từ `_template/api-flow.md`, bằng tiếng Việt (tên code/thuật ngữ giữ tiếng Anh).
4. **Chờ người dùng xác nhận.** Nếu sai/thiếu, sửa lại tài liệu. Chỉ khi được xác nhận mới làm bước
   tiếp theo (sửa/bổ sung code), và việc đó vẫn theo luồng Ask → Do → Log bình thường.

Mục tiêu: tài liệu phản ánh ĐÚNG code hiện tại — nếu chỗ nào chưa chắc thì ghi rõ "chưa chắc / cần xác
nhận", tuyệt đối không bịa.
