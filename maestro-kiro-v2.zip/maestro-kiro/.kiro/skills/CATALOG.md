# Danh mục skills

57 skill how-to đã tuyển cho web full-stack: **Java/Spring Boot · Node.js · Next.js · ReactJS · thư
viện UI · database**. Mỗi skill là một thư mục có `SKILL.md`. Nạp skill liên quan trước khi viết code
trong mảng đó; bắt đầu bằng `legacy-code-comprehension` để đọc code lạ.

## Backend — Java / Spring Boot

| Skill | Dùng cho |
|-------|----------|
| `java-spring-development` | Phát triển app Spring Boot end-to-end |
| `spring-boot-engineer` | Pattern service Spring Boot, starter, config |
| `spring-framework` | Spring lõi (DI, AOP, web, data) |
| `java-architect` | Kiến trúc & thiết kế Java |
| `api-design-principles` | Thiết kế API REST/GraphQL (resource, versioning, lỗi) |

## Data

| Skill | Dùng cho |
|-------|----------|
| `postgresql-best-practices` | Schema, index, query PostgreSQL |
| `redis-best-practices` | Cache / cấu trúc dữ liệu Redis |

## Frontend — ReactJS

| Skill | Dùng cho |
|-------|----------|
| `react` | Component, pattern, hiệu năng React |
| `react-modernization` | Hiện đại hoá/refactor code React |
| `react-query` | Server-state với TanStack Query |
| `redux-toolkit` | Quản lý state Redux Toolkit |
| `zustand-state-management` | Store Zustand |
| `vite` | Cấu hình build/dev Vite |
| `typescript-advanced-types` | Kiểu TypeScript cho code app |

## Frontend — Next.js

| Skill | Dùng cho |
|-------|----------|
| `next-best-practices` | Pattern & best practice App Router Next.js |
| `next-cache-components` | Caching & React Server Components trong Next.js |
| `native-data-fetching` | Data fetching phía server / pattern RSC |
| `vercel-react-best-practices` | Best practice React/Next trên Vercel |
| `vercel-composition-patterns` | Composition pattern cho React/Next |
| `deploy-to-vercel` | Deploy app Next.js/web lên Vercel |

## Thư viện UI & styling

| Skill | Dùng cho |
|-------|----------|
| `shadcn` | Component shadcn/ui |
| `mui` | Component Material UI |
| `tailwindcss` | Tailwind CSS |
| `tailwind-design-system` | Design system trên Tailwind |
| `tailwind-knowledge-patch` | Thay đổi Tailwind gần đây |
| `styled-components-best-practices` | styled-components |
| `scss-best-practices` | SCSS/Sass |
| `postcss-best-practices` | PostCSS |
| `framer-motion` | Animation (Framer Motion) |
| `gsap` | Animation (GSAP) |
| `accessibility-a11y` | Accessibility theo WCAG |
| `web-design-guidelines` | Hướng dẫn thiết kế UI/UX |

## Data & ORM

| Skill | Dùng cho |
|-------|----------|
| `postgresql-best-practices` | Schema, index, query PostgreSQL |
| `mysql-best-practices` | Schema & query MySQL |
| `neon-postgres` | Postgres serverless Neon |
| `supabase` | Supabase (DB, auth, storage) |
| `supabase-postgres-best-practices` | Pattern Postgres trên Supabase |
| `redis-best-practices` | Cache / cấu trúc dữ liệu Redis |
| `redis-js` | Redis từ Node.js |
| `upstash-redis-kv` | Redis/KV serverless Upstash |
| `prisma` | Prisma ORM |
| `prisma-development` | Làm việc với Prisma |
| `prisma-knowledge-patch` | Thay đổi Prisma gần đây |
| `drizzle-orm` | Drizzle ORM |
| `drizzle-knowledge-patch` | Thay đổi Drizzle gần đây |
| `typeorm` | TypeORM |

## Auth

| Skill | Dùng cho |
|-------|----------|
| `better-auth-best-practices` | Auth (email/OAuth/plugin) với Better Auth |

## Xuyên suốt

| Skill | Dùng cho |
|-------|----------|
| `legacy-code-comprehension` | Đọc & hiểu codebase lạ (quét trước) |
| `test-driven-development` | Quy trình TDD |
| `playwright-best-practices` | Test e2e Playwright |
| `webapp-testing` | Chiến lược test web app |
| `systematic-debugging` | Debug có phương pháp |
| `verification-before-completion` | Xác minh thay đổi thật sự xong trước khi nói xong |
