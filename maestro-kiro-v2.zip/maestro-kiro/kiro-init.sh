#!/usr/bin/env bash
# Tạo phần RIÊNG của dự án cho Maestro Kiro trong thư mục hiện tại.
# Contract, skills, hooks lấy từ global ~/.kiro (chạy install.sh một lần trước).
# Chỉ tạo steering riêng của dự án + WORKLOG (không đè file đã có).
set -euo pipefail

T="$HOME/.kiro/.templates"
if [ ! -d "$T" ]; then
  echo "Thiếu $T — hãy chạy install.sh một lần trước."; exit 1
fi

mkdir -p .kiro/steering

for f in product tech structure inventory; do
  if [ -f ".kiro/steering/$f.md" ]; then
    echo "bỏ qua .kiro/steering/$f.md (đã có)"
  else
    cp "$T/steering/$f.md" ".kiro/steering/$f.md"; echo "tạo   .kiro/steering/$f.md"
  fi
done

if [ -f WORKLOG.md ]; then echo "bỏ qua WORKLOG.md (đã có)"; else
  cp "$T/WORKLOG.md" WORKLOG.md; echo "tạo   WORKLOG.md"; fi

# Không commit WORKLOG.md lên repo, nhưng KHÔNG sửa .gitignore của dự án:
# dùng .git/info/exclude (ignore cục bộ, không được commit).
if [ -d .git ]; then
  EXCLUDE=".git/info/exclude"
  if grep -qxF "WORKLOG.md" "$EXCLUDE" 2>/dev/null; then
    echo "bỏ qua .git/info/exclude (WORKLOG.md đã được loại)"
  else
    printf '\n# Maestro Kiro — không commit worklog\nWORKLOG.md\n' >> "$EXCLUDE"
    echo "loại WORKLOG.md khỏi git qua .git/info/exclude (cục bộ, không commit, không đụng .gitignore)"
  fi
else
  echo "lưu ý: chưa phải git repo — sau khi 'git init' hãy chạy lại để loại WORKLOG.md khỏi git."
fi

echo
echo "Xong. Hãy điền .kiro/steering/{product,tech,structure,inventory}.md cho dự án này"
echo "(hoặc mở trong Kiro và bật hook first-run-steering để tự quét & điền)."
echo "WORKLOG.md nằm ở gốc dự án — ghi việc Kiro làm trong DỰ ÁN NÀY, và không bị commit lên."
